<?php

class Document extends Eloquent {

    protected $table = 'documents';

}
