<?php

class Requests extends Eloquent {

    protected $table = 'request';

}
