<?php

class ScheduleMeta extends Eloquent {

    protected $table = 'schedule_meta';

}
