/*! ========================================================================
 * invoice-print.js
 * Page/renders: page-invoice-printable.html
 * Plugins used: 
 * ======================================================================== */
$(function () {
    // Popup browser Print
    // ================================
    window.print();
});