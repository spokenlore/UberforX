<?php

class Schedules extends Eloquent {

    protected $table = 'schedules';

}
