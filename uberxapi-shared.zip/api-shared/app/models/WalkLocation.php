
<?php

class WalkLocation extends Eloquent {

    protected $table = 'walk_location';

}
