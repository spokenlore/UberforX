@extends('layout')

@section('content')

<div class="row third-portion">
    <div class="tab-content">
        <div class="tab-pane fade" id="option3">
            <div class="row tab-content-caption">
                <div class="container">
                    <div class="col-md-10 big-text">
                        <p><?= $title ?></p>
                    </div>
                    
                </div>
            </div>
            
            <div class="row editable-content-div">
             <div class="container">
            <form method="post" action="<?php echo web_url(); ?>/admin/settings"  enctype="multipart/form-data">
            <h2>Basic App Settings</h2> 
            <hr>
            <table class="display" cellspacing="0" width="100%" style="position:relative;left:20px;">
                <tbody>
                    <?php foreach ($settings as $setting) { 
                       if($setting->page == 1){ 
                        if( $setting->key != 'default_distance_unit' && $setting->key != 'sms_notification' && $setting->key != 'email_notification' && $setting->key != 'push_notification' && $setting->key != 'default_charging_method_for_users') { ?>
                    <tr>
                      <td id="col1"><?php echo ucwords(str_replace("_", " ", $setting->key)); ?>&nbsp;<a href="#" data-toggle="tooltip" title="<?= $setting->tool_tip; ?>"><img src="<?php echo web_url(); ?>/image/icon-tooltip.jpg"></a></td>
                      <td id="col2">
                      <?php if((strstr($setting->key,'email_') || strstr($setting->key,'sms_'))& $setting->key != 'admin_email_address' ) {?>
                      <textarea rows="5" cols="50" name="<?php echo $setting->id; ?>" ><?php echo $setting->value; ?></textarea>
                      <?php } else{?>
                      <input type="text" name="<?php echo $setting->id; ?>" value="<?php echo $setting->value; ?>">
                      <?php } ?>
                      </td>
                    </tr>
                    <?php } else{ ?>
                        <tr>
                      <td id="col1"><?php echo ucwords(str_replace("_", " ", $setting->key)); ?>&nbsp;<a href="#" data-toggle="tooltip" title="<?= $setting->tool_tip; ?>"><img src="<?php echo web_url(); ?>/image/icon-tooltip.jpg"></a></td>
                      <td id="col2">
                      <select name="<?php echo $setting->id; ?>">
                          <option value="1" <?php if($setting->value == 1) { echo "selected"; }?> >
                          <?php if($setting->key == 'default_charging_method_for_users') {?>
                          Time and Distance Based
                          <?php } elseif($setting->key == 'default_distance_unit') { ?>
                          Miles
                          <?php }else{ ?>
                          Yes
                          <?php } ?>
                          </option>
                          <option value="0" <?php if($setting->value == 0) { echo "selected"; }?> >
                          <?php if($setting->key == 'default_charging_method_for_users') {?>
                          Fixed Price
                          <?php } elseif($setting->key == 'default_distance_unit') { ?>
                          KM
                          <?php }else{ ?>
                          No
                          <?php } ?>
                          </option>
                      </select>
                      
                      </td>
                    </tr>
                    <?php } ?>
                    <?php } ?>


                    <?php } ?>
                    
                    <tr>
                        <td></td>
                        <td><br><input type="submit" value="Update Changes" class="btn btn-green"></td>
                    </tr>
                    
                </tbody>
            </table> 
            
            <h2>SMS Templates</h2>
            <hr>
                       <table class="display" cellspacing="0" width="100%" style="position:relative;left:20px;">
                <tbody>
                    <?php foreach ($settings as $setting) { 
                       if($setting->page == 2){ 
                        if( $setting->key != 'sms_notification' && $setting->key != 'email_notification' && $setting->key != 'push_notification' && $setting->key != 'default_charging_method_for_users') { ?>
                    <tr>
                      <td id="col1"><?php echo ucwords(str_replace("_", " ", $setting->key)); ?>&nbsp;<a href="#" data-toggle="tooltip" title="<?= $setting->tool_tip; ?>"><img src="<?php echo web_url(); ?>/image/icon-tooltip.jpg"></a></td>
                      <td id="col2">
                      <?php if((strstr($setting->key,'email_') || strstr($setting->key,'sms_'))& $setting->key != 'admin_email_address' ) {?>
                      <textarea rows="5" cols="50" name="<?php echo $setting->id; ?>" ><?php echo $setting->value; ?></textarea>
                      <?php } else{?>
                      <input type="text" name="<?php echo $setting->id; ?>" value="<?php echo $setting->value; ?>">
                      <?php } ?>
                      </td>
                    </tr>
                    <?php } else{ ?>
                        <tr>
                      <td id="col1"><?php echo ucwords(str_replace("_", " ", $setting->key)); ?>&nbsp;<a href="#" data-toggle="tooltip" title="<?= $setting->tool_tip; ?>"><img src="<?php echo web_url(); ?>/image/icon-tooltip.jpg"></a></td>
                      <td id="col2">
                      <select name="<?php echo $setting->id; ?>">
                          <option value="1" <?php if($setting->value == 1) { echo "selected"; }?> >
                          <?php if($setting->key == 'default_charging_method_for_users') {?>
                          Time and Distance Based
                          <?php } else { ?>
                          Yes
                          <?php } ?>
                          </option>
                          <option value="0" <?php if($setting->value == 0) { echo "selected"; }?> >
                          <?php if($setting->key == 'default_charging_method_for_users') {?>
                          Fixed Price
                          <?php } else { ?>
                          No
                          <?php } ?>
                          </option>
                      </select>
                      
                      </td>
                    </tr>
                    <?php } ?>
                    <?php } ?>


                    <?php } ?>
                    
                    <tr>
                        <td></td>
                        <td><br><input type="submit" value="Update Changes" class="btn btn-green"></td>
                    </tr>
                    
                </tbody>
            </table> 
          
            <h2>Email Templates</h2> 
            <hr>
                      <table class="display" cellspacing="0" width="100%" style="position:relative;left:20px;">

                <tbody>
                    <?php foreach ($settings as $setting) { 
                       if($setting->page == 3){ 
                        if( $setting->key != 'sms_notification' && $setting->key != 'email_notification' && $setting->key != 'push_notification' && $setting->key != 'default_charging_method_for_users') { ?>
                    <tr>
                      <td id="col1"><?php echo ucwords(str_replace("_", " ", $setting->key)); ?>&nbsp;<a href="#" data-toggle="tooltip" title="<?= $setting->tool_tip; ?>"><img src="<?php echo web_url(); ?>/image/icon-tooltip.jpg"></a></td>
                      <td id="col2">
                      <?php if((strstr($setting->key,'email_') || strstr($setting->key,'sms_'))& $setting->key != 'admin_email_address' ) {?>
                      <textarea rows="5" cols="50" name="<?php echo $setting->id; ?>" ><?php echo $setting->value; ?></textarea>
                      <?php } else{?>
                      <input type="text" name="<?php echo $setting->id; ?>" value="<?php echo $setting->value; ?>">
                      <?php } ?>
                      </td>
                    </tr>
                    <?php } else{ ?>
                        <tr>
                      <td id="col1"><?php echo ucwords(str_replace("_", " ", $setting->key)); ?>&nbsp;<a href="#" data-toggle="tooltip" title="<?= $setting->tool_tip; ?>"><img src="<?php echo web_url(); ?>/image/icon-tooltip.jpg"></a></td>
                      <td id="col2">
                      <select name="<?php echo $setting->id; ?>">
                          <option value="1" <?php if($setting->value == 1) { echo "selected"; }?> >
                          <?php if($setting->key == 'default_charging_method_for_users') {?>
                          Time and Distance Based
                          <?php } else { ?>
                          Yes
                          <?php } ?>
                          </option>
                          <option value="0" <?php if($setting->value == 0) { echo "selected"; }?> >
                          <?php if($setting->key == 'default_charging_method_for_users') {?>
                          Fixed Price
                          <?php } else { ?>
                          No
                          <?php } ?>
                          </option>
                      </select>
                      
                      </td>
                    </tr>
                    <?php } ?>
                    <?php } ?>


                    <?php } ?>
                    
                    <tr>
                        <td></td>
                        <td><br><input type="submit" value="Update Changes" class="btn btn-green"></td>
                    </tr>
                    
                </tbody>
            </table>
            
            </form>

            </div>       
               
            </div>
            <!--</form>-->
        </div>
    </div>
</div>

<?php
if($success == 1) { ?>
<script type="text/javascript">
    alert('Settings Updated Successfully');
</script>
<?php } ?>
<?php
if($success == 2) { ?>
<script type="text/javascript">
    alert('Sorry Something went Wrong');
</script>
<?php } ?>

<script>
   $(function () { $("[data-toggle='tooltip']").tooltip(); });
</script>

@stop