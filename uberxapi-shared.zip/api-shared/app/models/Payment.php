
<?php

class Payment extends Eloquent {

    protected $table = 'payment';

}
